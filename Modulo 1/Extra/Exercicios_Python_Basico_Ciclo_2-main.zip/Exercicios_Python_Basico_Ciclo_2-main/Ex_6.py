# Calcule a média das notas utilizando loops for aninhados (um loop dentro do outro)

# O código deve exibir o resultado abaixo:

# Aluno: Fabrício | Média Final: 7.94
# Aluno: Leandro | Média Final: 8.31
# Aluno: Marcela | Média Final: 9.19


# ------------------------------------------ ESCREVA SEU CÓDIGO ABAIXO -----------------------------------------------------------
# Não altere e nem apague este dicionário
alunos = {
    'Fabrício' : ['9.5', '10', '6.75', '5.5'],
    'Leandro' : ['7', '8', '9.75', '8.5'],
    'Marcela' : ['9.5', '9', '9.75', '8.5'],
}


# LOOP FOR
