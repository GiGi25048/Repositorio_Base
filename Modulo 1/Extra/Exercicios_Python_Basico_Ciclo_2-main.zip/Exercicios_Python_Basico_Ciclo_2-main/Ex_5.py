# Utilizando tanto um loop while quanto um loop for, escreva um código que exiba na tela o resultado abaixo:

# 1 Fabrício
# 2 Leandro
# 3 Marcela


# ------------------------------------------ ESCREVA SEU CÓDIGO ABAIXO -----------------------------------------------------------
lista = ['Fabrício', 'Leandro', 'Marcela', [1, 2, 3, 0]] # Não apague e nem altere essa lista


# LOOP WHILE




# LOOP FOR


