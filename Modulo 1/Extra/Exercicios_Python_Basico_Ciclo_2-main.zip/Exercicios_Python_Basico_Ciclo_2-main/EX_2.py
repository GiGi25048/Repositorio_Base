# Utilize um loop while e um loop for para percorrer a lista e exibir os valores dos items contidos na lista

# ------------------------------------------ ESCREVA SEU CÓDIGO ABAIXO -----------------------------------------------------------

frutas = ['maçã', 'banana', 'morango', 'uva', 'laranja']

# LOOP WHILE






# LOOP FOR



